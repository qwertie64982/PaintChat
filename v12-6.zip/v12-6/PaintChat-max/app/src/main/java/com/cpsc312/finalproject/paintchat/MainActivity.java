package com.cpsc312.finalproject.paintchat;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class MainActivity extends AppCompatActivity {

    static final int REQUEST_CAMERA = 1;
    static final int REQUEST_GALLERY = 2;
    String mCurrentPhotoPath;

    //TODO: Make Buttons Prettier
    /*  TODO: Wire buttons -
        resumeImageButton
        newPhotoButton
        existingPhotoButton
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // reference buttons
        Button newImageButton = (Button) findViewById(R.id.startNewImageButton);
        Button resumeImageButton = (Button) findViewById(R.id.resumeLastImageButton);
        Button newPhotoButton = (Button) findViewById(R.id.takeNewPhotoButton);
        Button existingPhotoButton = (Button) findViewById(R.id.useExistingPhotoButton);

        // wire onClickListeners
        newImageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onStartNewImageClicked();
            }
        });
    }



    public void onStartNewImageClicked(){
        AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
        builder.setTitle(R.string.newImageAlertTitle)
                .setMessage(R.string.newImageAlertBody)
                .setPositiveButton(R.string.yes, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        Intent intent = new Intent(MainActivity.this, DrawActivity.class);
                        intent.putExtra("mode", "new");
                        startActivity(intent);
                    }
                })
                .setNegativeButton(R.string.no, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {

                    }
                });
        AlertDialog newImageDialog = builder.create();
        newImageDialog.show();
    }

    public void onTakeNewPhotoClicked(){
        AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
        builder.setTitle(R.string.newPhotoAlertTitle)
                .setMessage(R.string.newImageAlertBody)
                .setPositiveButton(R.string.yes, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                        takePictureIntent.putExtra("mode", "camera");
                        if (takePictureIntent.resolveActivity(getPackageManager()) != null) {
                            File photoFile = null;
                            try {
                                photoFile = createImageFile();
                            } catch (IOException ex) {

                            }
                        }
                    }
                })
                .setNegativeButton(R.string.no, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {

                    }
                });
        AlertDialog newPhotoDialog = builder.create();
        newPhotoDialog.show();
    }



    private File createImageFile() throws IOException {
        // Create an image file name
        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
        String imageFileName = "JPEG_" + timeStamp + "_";
        File storageDir = getExternalFilesDir(Environment.DIRECTORY_PICTURES);
        File image = File.createTempFile(
                imageFileName,  /* prefix */
                ".jpg",         /* suffix */
                storageDir      /* directory */
        );

        // Save a file: path for use with ACTION_VIEW intents
        mCurrentPhotoPath = image.getAbsolutePath();
        return image;
    }}
